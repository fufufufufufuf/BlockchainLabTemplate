import upload from "./upload.png";
import creator from "./creator1.png";

export default { upload, creator };
