//0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512

import voting from './Create.json';

export const VotingAddress = '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512';
export const VotingAddressABI = voting.abi;